import '../styles/Footer.css'
function Footer() {
    return (
        <footer>
            &copy; RumahRafif 2024
        </footer>
    )
}

export default Footer